import React from 'react';

const welcome = props => (
  <div>
    <h1>The Welcome Page</h1>
  </div>
);

export default welcome;
