import React from 'react';

const noMatch = () => (
    <h1 style={{textAlign: 'center'}}>Page not found</h1>
);

export default noMatch;