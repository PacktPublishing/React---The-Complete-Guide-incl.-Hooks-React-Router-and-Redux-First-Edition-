import React from 'react';

const user = props => (
  <div>
    <h1>The User Page</h1>
  </div>
);

export default user;
